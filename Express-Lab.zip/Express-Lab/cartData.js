let cartData = [      
    {
    id:"0",
    product: "Cat Food",
    price: "$5.00",
    quantity: "1",
    },
    {
    id:"1",
    product: "Dog Food",
    price: "$5.00",
    quantity: "2",    
    },
    {
    id:"2",
    product: "Human Food",
    price: "$10.00",
    quantity: "2",    
    },
    {
    id:"3",
    product: "Fish Food",
    price: "$1.00",
    quantity: "5",    },
    {
    id:"4",
    product: "Turtle Food",
    price: "$4.00",
    quantity: "2",
}];

module.exports = cartData;